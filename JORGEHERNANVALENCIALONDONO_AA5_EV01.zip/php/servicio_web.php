<?php
// Iniciar sesión (si no está iniciada)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Función para validar la autenticación
function autenticarUsuario($usuario, $contrasena) {
    // Lógica de autenticación
    // Se asume que el usuario es "usuario" y la contraseña es "contrasena"
    if ($usuario == "usuario" && $contrasena == "contrasena") {
        $_SESSION['usuario'] = $usuario; // Iniciar sesión
        return true;
    } else {
        return false;
    }
}

// Verificar si se recibieron datos POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibir datos del formulario 
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    // Intentar autenticar al usuario
    if (autenticarUsuario($usuario, $contrasena)) {
        echo "Autenticación satisfactoria";
    } else {
        echo "Error en la autenticación";
    }
} else {
    echo "Método no permitido"; // Manejar solicitudes que no son POST
}
?>