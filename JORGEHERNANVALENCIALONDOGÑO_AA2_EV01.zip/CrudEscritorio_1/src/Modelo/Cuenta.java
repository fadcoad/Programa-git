package Modelo;

public class Cuenta {
    public static int x=2;
    public static registro [] cuenta= new registro[100];   
    
    //Object selectedItem

    void Crear(String text, String text0, int parseInt, String text1, int parseInt0, int parseInt1, String text2, int parseInt2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public class registro {
        String Cuenta;
	String  Nombre;
	int  Saldo;
	String  NIP;
        int Inversion;        
        int Interes;
        String Cargo;
        int Salario;
        int Ganancia;
        
        
        
    }
       
    public void Prellenar(){
        cuenta[1]=new registro();    
        cuenta[1].Cuenta="admon";
        cuenta[1].Nombre="Administrador";
        cuenta[1].Saldo=0;
        cuenta[1].NIP="admon"; 
        cuenta[1].Inversion=0;
        cuenta[1].Interes=0;
        cuenta[1].Cargo="Administrador";
        cuenta[1].Salario=0;
        cuenta[1].Ganancia=0;
    }
	     
    public void Crear(String NoCuenta, String nombre,int saldo, String nip, int inversion, int interes, String cargo, float salario, float ganancia) {    
        cuenta[x]=new registro();    
        cuenta[x].Cuenta=NoCuenta;
        cuenta[x].Nombre=nombre;
        cuenta[x].Saldo=saldo;
        cuenta[x].NIP=nip; 
        cuenta[x].Inversion=inversion;
        cuenta[x].Interes=interes;
        cuenta[x].Cargo=cargo;
        cuenta[x].Salario=(int) salario;
        cuenta[x].Ganancia=(int) ganancia;
        
        //JOptionPane.showMessageDialog(null,"cuenta creada");
        //System.out.print("\nLa Cuenta con los siguientes Datos: \n\n");                                  
        //System.out.println("Cuenta  \t" +"Titular \t" +"Saldo \t" +"NIP");
        //System.out.println(cuenta[x].Cuenta + "\t" +cuenta[x].Titular + "\t" +cuenta[x].Saldo + "\t" +cuenta[x].NIP);    
        //System.out.print("\nHa sido creada satisfactoriamente, presione una tecla para continuar..."); 
        x++;   //Equivamente a x=x+1;    
    }
	
    public void Abonar(String Nocuenta, int deposito) {            
            for(int i=1;i<x;i++)    {                                       
                if (Nocuenta.equals(cuenta[i].Cuenta))   {    
                    cuenta[i].Saldo=cuenta[i].Saldo+deposito;
                    System.out.print("Operacion realizada exitosamente \nPresione una tecla para continuar");                    
                }        
            }    
	}
	
  
    
    public boolean Validar(String Nocuenta, String NIP ) {        
        boolean band=false;
        for(int i=1;i<x;i++)    {                                       
            if (Nocuenta.equals(cuenta[i].Cuenta) && NIP.equals(cuenta[i].NIP))  {
                band=true; 
                break;
            }
        }                   
        return band;
    }
    
    /**
     *
     * @param Nocuenta
     * @param retiro
     */
    public void Retirar(String Nocuenta, int retiro) {
        
        
        for(int i=1;i<x;i++)  
        
        if (cuenta[i].Saldo-retiro>=500&&Nocuenta.equals(cuenta[i].Cuenta))   {    
                    cuenta[i].Saldo=cuenta[i].Saldo-retiro;
                    System.out.print("Operacion realizada exitosamente");                    
                }  else {System.out.print("Saldo insuficiente");               
                
        } }
        
    /**
     *
     * @param Nocuenta
     * @param inversionn
     */
    public void Invertir(String Nocuenta, int inversionn) {
        
        
        for(int i=1;i<x;i++) 
            
            
            
        
        if (cuenta[i].Saldo-inversionn>=10000&&Nocuenta.equals(cuenta[i].Cuenta))   {    
                    cuenta[i].Inversion=cuenta[i].Inversion+inversionn;
                    cuenta[i].Saldo=cuenta[i].Saldo-inversionn;
                    System.out.print("Operacion realizada exitosamente");                    
                }  else {System.out.print("Saldo insuficiente");               
                
        }
        
        
        
            }    

}
/*public void Retirar(String Nocuenta, int retiro) {
        for(int i=1;i<x;i++)  
        
        if (cuenta[i].Saldo-retiro>=500&&Nocuenta.equals(cuenta[i].Cuenta))   {    
                    cuenta[i].Saldo=cuenta[i].Saldo-retiro;
                    System.out.print("Operacion realizada exitosamente");                    
                }  else{System.out.print("Saldo insuficiente");
        }      
            }    

    }*/