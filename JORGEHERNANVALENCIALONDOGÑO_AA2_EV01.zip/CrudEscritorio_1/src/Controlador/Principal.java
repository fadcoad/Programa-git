
package Controlador;

import Modelo.ConsultasEmpleado;
import Modelo.Empleado;
import Vista.frmEmpleado;


public class Principal {
    // Resto del código de la clase Principal

    static {
        Empleado mod = new Empleado();
        ConsultasEmpleado modC = new ConsultasEmpleado();
        frmEmpleado frm = new frmEmpleado();
        ControladorEmpleado crtl = new ControladorEmpleado(mod, modC, frm);
        crtl.iniciar();
        frm.setVisible(true);
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
